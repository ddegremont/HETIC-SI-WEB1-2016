var templateModele = `
    <div id="containerModel">
        <select id="typeVehicule">
            <option value="">Type de véhicule</option>
            <option value="">Voiture</option>
            <option value="">Moto</option>
        </select>
        <select id="typeMarque">
            <option value="Renault">Marque</option>
            <option value="Renault">Renault</option>
            <option value="Peugeot">Peugeot</option>
            <option value="Citroen">Citroen</option>
            <option value="Volkswagen">Volkswagen</option>
            <option value="BMW">BMW</option>
            <option value="Ford">Ford</option>
            <option value="Fiat">Fiat</option>
            <option value="Audi">Audi</option>
            <option value="Mercedes">Mercedes</option>
            <option value="Opel">Opel</option>
            <option value="Seat">Seat</option>
        </select>
        <select id="typeModele">
            <option value="2CV">Modèle</option>
            <option value="2CV">2CV</option>
            <option value="Acadienne">Acadienne</option>
            <option value="Berlingo">Berlingo</option>
        </select>
        <select id="typeMotorisation">
            <option value="Boite Manuelle">Motorisation</option>
            <option value="Boite Manuelle">Boite Manuelle</option>
            <option value="">Boite Automatique</option>
        </select>
    </div>
`;

var templateImmatriculation = `
    <div id="containerImmatriculation">
        <p>Entrer votre numéro d'immatriculation</p>
        <div id="plaqueImmatriculation">
            <div id="bleu1"></div>
            <input type="text" id="plaque" placeholder="GA-126-AB">
            <div id="bleu2"></div>
        </div>
    </div>
`;

var templateCarteGrise = `
    <div id="containerCarteGrise">
        <p>Entrer votre numéro de carte Grise</p>
        <div id="numeroCarteGrise">
            <div id="gris1"></div>
            <input type="text" id="plaque" placeholder="GA-126-AB">
            <div id="gris2"></div>
        </div>
   </div>
`;

$('#selectionVehicule').click(function () {
    $('#bloc_search').toggleClass('classActive'); // L'élément active
    $('.byModele').toggleClass('ongletActive'); // L'élément active
    if($('#bloc_search').hasClass('classActive'))
    {
        $('#bloc_search').show();
        $('#content').append(templateModele);
    }else{
        $('#bloc_search').hide();
        $('#content').empty();
        $('.ongletActive').toggleClass('ongletActive'); // L'élément active
    }
});

$('.byModele').click(function () {
    // Au clic on suprime le template précédent puis on le remplace par un template
    $('#content').empty();
    $('#content').append(templateModele);
    // Si l'imatriculation ou la carte grise à l'onglet active
    var a = $('.byImmatriculation').hasClass('ongletActive');
    var b = $('.byCarteGrise').hasClass('ongletActive');

    if( a == true || b == true){
        $('.ongletActive').removeClass('ongletActive'); // Enlève la classe active
        $('.byModele').addClass('ongletActive'); // Puis le rajoute sur l'élément en cours
    }
});

$('.byImmatriculation').click(function () {
    $('#content').empty();
    $('#content').append(templateImmatriculation);
    var a = $('.byModele').hasClass('ongletActive');
    var b = $('.byCarteGrise').hasClass('ongletActive');
    if( a == true || b == true){
        $('.ongletActive').removeClass('ongletActive'); // L'élément active
        $('.byImmatriculation').addClass('ongletActive'); // L'élément active
    }
});

$('.byCarteGrise').click(function () {
    $('#content').empty();
    $('#content').append(templateCarteGrise);
    var a = $('.byModele').hasClass('ongletActive');
    var b = $('.byImmatriculation').hasClass('ongletActive');
    if( a == true || b == true){
        $('.ongletActive').removeClass('ongletActive'); // L'élément active
        $('.byCarteGrise').addClass('ongletActive'); // L'élément active
    }
});

$(document).ready(function(){
    $(".sous_categories_gras .title_categ").click(function(e){
        e.preventDefault();
        $(this).next('ul').toggleClass('none');
   });

   $(".popup_recherche .filtres_recherche").click(function(e){
        e.preventDefault();
        $(this).parent().next('ul').toggleClass('none');
   });

   $('.menuBurger').on('click', function(e){
        e.preventDefault();
        $('#apparition_menu').toggleClass('visible');
    });
});


$('.btn_search').on('click', function(e) {
    e.preventDefault();
    console.log('clic click')
    if( $(this).hasClass('link_to') ){
        window.location = 'recherche.html';
    }
});

$('#choix_vehicule .vehicule').on('click', function(e){
    e.preventDefault();
    $('#choix_vehicule .vehicule').removeClass('active');
    $('.select_type').removeClass('visible');

    $(this).addClass('active');
    if( $(this).hasClass('moto')){
        $('#select_type_moto').addClass('visible');
    } else {
        $('#select_type').addClass('visible');
    }
})