/**
* Created by nabethkevin on 17/05/2016.
*/
$(window).load(function() {
  $(".loader").fadeOut("1000");
})

$(document).ready(function (){

  $(".navigation ul.subMenu").hide();
  $('#formulaire2').hide();
  $('#formulaire3').hide();
  $('#croixburger').hide();
  $('#croixconn').hide();
  $('#croixsch').hide();
  $('#recherche').css('display','none');
  $('.row').hide();
});

function isScrolledIntoView(elem) {
  var docViewTop = $(window).scrollTop();
  var docViewBottom = docViewTop + $(window).height();

  var elemTop = $(elem).offset().top;
  var elemBottom = elemTop + $(elem).height();

  return ((elemBottom <= docViewBottom) && (elemTop >= docViewTop));
}

$(window).scroll(function(){

  if (isScrolledIntoView('.row') === true) {
    $('.row').addClass('bounceInUp');
    $('.row').show();
  }
});

$('#carlistid').change(function () {

    if ( $('#carlistid').val() == 1 ){
      $('section').css('background-image', 'url(images/garage.jpg)');
    }else if ($('#carlistid').val() == 2){
      $('section').css('background-image', 'url(images/carte-grise.jpg)');
    }else if ($('#carlistid').val() == 0){
      $('section').css('background-image', 'url(images/bmw.jpg)');
    }

});

$('#burger').click(function() {
  $('#menu').animate({'width': '350px'}, '2000');
  $('#header').animate({'left': '-350px'}, '2000');
  $('#section').animate({'left': '-350px'}, '2000');
  $('article').animate({'padding-right': '350px'}, '2000');
  $('footer').animate({'margin-left': '-350px'}, '2000');
  $('body').css("overflow", "hidden");
  $('#listemenu').css("overflow", "visible");
  $('#burger').hide();
  $('#croixburger').show();
  $('#panier').show();
  $('#croixconn').hide();
  $('#menupanier').animate({'width': '0px'}, '2000');
  $('#text-menu').removeClass('fadeIn');
  $('#text-menu').addClass('animated fadeOut');
});

$('#croixburger').click(function () {
  $('#menu').animate({'width': '0px'}, '2000');
  $('#header').animate({'left': '0px'}, '2000');
  $('#section').animate({'left': '0px'}, '2000');
  $('article').animate({'padding-right': '0px'}, '2000');
  $('footer').animate({'margin-left': '0px'}, '2000');
  $('body').css("overflow", "visible");
  $('#burger').show();
  $('#croixburger').hide();
  $('#text-menu').removeClass('fadeOut');
  $('#text-menu').addClass('animated fadeIn');
});

$('#text-menu').click(function() {
  $('#menu').animate({'width': '350px'}, '2000');
  $('#header').animate({'left': '-350px'}, '2000');
  $('#section').animate({'left': '-350px'}, '2000');
  $('article').animate({'padding-right': '350px'}, '2000');
  $('footer').animate({'margin-left': '-350px'}, '2000');
  $('body').css("overflow", "hidden");
  $('#listemenu').css("overflow", "visible");
  $('#burger').hide();
  $('#croixburger').show();
  $('#panier').show();
  $('#croixconn').hide();
  $('#menupanier').animate({'width': '0px'}, '2000');
  $('#text-menu').removeClass('fadeIn');
  $('#text-menu').addClass('animated fadeOut');
});

$('#panier').click(function () {
  $('#menupanier').animate({'width': '350px'}, '2000');
  $('#header').animate({'left': '-350px'}, '2000');
  $('#section').animate({'left': '-350px'}, '2000');
  $('article').animate({'padding-right': '350px'}, '2000');
  $('footer').animate({'margin-left': '-350px'}, '2000');
  $('body').css("overflow", "hidden");
  $('#panier').hide();
  $('#croixconn').show();
  $('#burger').show();
  $('#croixburger').hide();
  $('#menu').animate({'width': '0px'}, '2000');
  $('#text-conn').removeClass('fadeIn');
  $('#text-conn').addClass('animated fadeOut');
});

$('#text-conn').click(function () {
  $('#menupanier').animate({'width': '350px'}, '2000');
  $('#header').animate({'left': '-350px'}, '2000');
  $('#section').animate({'left': '-350px'}, '2000');
  $('article').animate({'padding-right': '350px'}, '2000');
  $('footer').animate({'margin-left': '-350px'}, '2000');
  $('body').css("overflow", "hidden");
  $('#panier').hide();
  $('#croixconn').show();
  $('#burger').show();
  $('#croixburger').hide();
  $('#menu').animate({'width': '0px'}, '2000');
  $('#text-conn').removeClass('fadeIn');
  $('#text-conn').addClass('animated fadeOut');
});

$('#croixconn').click(function () {
  $('#menupanier').animate({'width': '0px'}, '2000');
  $('#header').animate({'left': '0px'}, '2000');
  $('#section').animate({'left': '0px'}, '2000');
  $('article').animate({'padding-right': '0px'}, '2000');
  $('footer').animate({'margin-left': '0px'}, '2000');
  $('body').css("overflow", "visible");
  $('#panier').show();
  $('#croixconn').hide();
  $('#text-conn').removeClass('fadeOut');
  $('#text-conn').addClass('animated fadeIn');
});



$('#loupe').click(function () {
  $('#recherche').animate({'width': '350px'}, '2000');
  $('#header').animate({'left': '350px'}, '2000');
  $('#section').animate({'left': '350px'}, '2000');
  $('article').animate({'padding-left': '350px'}, '2000');
  $('footer').animate({'margin-left': '350px'}, '2000');
  $('body').css("overflow", "hidden");
  $('#loupe').hide();
  $('#croixsch').show();
  $('#recherche').css('display','block');
  $('#textcatg').removeClass('fadeIn');
  $('#textcatg').addClass('animated fadeOut');
});

$('#textcatg').click(function () {
  $('#recherche').animate({'width': '350px'}, '2000');
  $('#header').animate({'left': '350px'}, '2000');
  $('#section').animate({'left': '350px'}, '2000');
  $('article').animate({'padding-left': '350px'}, '2000');
  $('footer').animate({'margin-left': '350px'}, '2000');
  $('body').css("overflow", "hidden");
  $('#loupe').hide();
  $('#croixsch').show();
  $('#recherche').css('display','block');
  $('#textcatg').removeClass('fadeIn');
  $('#textcatg').addClass('animated fadeOut');
});


$('#croixsch').click(function () {
  $('#recherche').animate({'width': '0px'}, '2000');
  $('#header').animate({'left': '0px'}, '2000');
  $('#section').animate({'left': '0px'}, '2000');
  $('article').animate({'padding-left': '0px'}, '2000');
  $('footer').animate({'margin-left': '0px'}, '2000');
  $('body').css("overflow", "visible");
  $('#loupe').show();
  $('#croixsch').hide();
  $('#recherche').animate({'display':'none'});
  $('#textcatg').removeClass('fadeOut');
  $('#textcatg').addClass('fadeIn');

  setTimeout(function(){
    $('#recherche').css('display','none');
  },250);


});


$('#immatriculation').click(function () {
  $('#formulaire1').hide();
  $('#formulaire2').show();
  $('#formulaire2').addClass('animated fadeIn');
  $('#formulaire3').hide();
  $('#immatriculation').addClass('selected');
  $('#model').removeClass('selected');
  $('#grise').removeClass('selected');
  $('section').css("background-image", "url(images/garage.jpg)");

});

$('#model').click(function () {
  $('#formulaire1').show();
  $('#formulaire1').addClass('animated fadeIn');
  $('#formulaire2').hide();
  $('#formulaire3').hide();
  $('#immatriculation').removeClass('selected');
  $('#model').addClass('selected');
  $('#grise').removeClass('selected');
  $('section').removeClass('animated fadeIn');
  $('section').css("background-image", "url(images/bmw.jpg)");

});

$('#grise').click(function () {
  $('#formulaire1').hide();
  $('#formulaire3').addClass('animated fadeIn');
  $('#formulaire2').hide();
  $('#formulaire3').show();
  $('#immatriculation').removeClass('selected');
  $('#model').removeClass('selected');
  $('#grise').addClass('selected');
  $('section').css("background-image", "url(images/carte-grise.jpg)");

});

$( "#recherche" ).delegate( "img", "click", function() {
  $(this).toggleClass( "activearrow" );
  $('img').not(this).removeClass('activearrow');
});

  var status = 0;

$( "#recherche" ).delegate( ".piece", "click", function() {
  if(status == 0){
    $(this).next('.liste').css('display','block');
    $(this).find('.arrow').toggleClass( "activearrow" );
    status = 1;
    console.log(status);
  }else if(status == 1) {
    $('.liste').css('display','none');
    status = 0;
    $('.arrow').removeClass( "activearrow" );
  }
});
